#### Part A: Datagram Socket Programming
The objective is to design a String Processing Server (SPS). This SPS carries out string operations as requested by a client. Your server must offer two operations:
- number of vowels (vLength) in a string
- String Disemvoweling

#### Part B: TCP Socket Programming
Repeat Part A using TCP sockets to produce (ServerTCP.xxx, ClientTCP.c). The client must be written in C. The server must be written in any language other than C or C++.
